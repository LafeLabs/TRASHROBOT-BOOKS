<?php


mkdir("introduction");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/introduction/php/replicator.txt","introduction/replicator.php");
mkdir("buy");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/buy/php/replicator.txt","buy/replicator.php");
mkdir("install");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/install/php/replicator.txt","install/replicator.php");
mkdir("linux");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/linux/php/replicator.txt","linux/replicator.php");
mkdir("servers");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/servers/php/replicator.txt","servers/replicator.php");
mkdir("markdown");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/markdown/php/replicator.txt","markdown/replicator.php");
mkdir("learnhtml");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/learnhtml/php/replicator.txt","learnhtml/replicator.php");
mkdir("learncss");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/learncss/php/replicator.txt","learncss/replicator.php");
mkdir("learnjavascript");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/learnjavascript/php/replicator.txt","learnjavascript/replicator.php");
mkdir("learnphp");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/learnphp/php/replicator.txt","learnphp/replicator.php");
mkdir("python");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/python/php/replicator.txt","python/replicator.php");
mkdir("arduino");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/arduino/php/replicator.txt","arduino/replicator.php");
mkdir("power");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/power/php/replicator.txt","power/replicator.php");
mkdir("wireless");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/wireless/php/replicator.txt","wireless/replicator.php");
mkdir("operations");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/operations/php/replicator.txt","operations/replicator.php");
mkdir("teaching");
copy("https://raw.githubusercontent.com/LafeLabs/pi/main/teaching/php/replicator.txt","teaching/replicator.php");







?>
<a href = "index.html">CLICK TO GO TO PAGE</a>
<style>
a{
    font-size:3em;
}
</style>
