[home](index.html)

# Trash Robot Brand

Just as large corporations create a whole brand image and brand language which they use to express their brand, we do with Trash Robot in a way that is not property and has no central control.  

- Googly eyes
- rainbows
- rainbow duct tape
- cardboard
- geometry made from the Geometron Shape Set using standard symmetries and scales
- Geometry as a way of life and belief system which is an alternative to numbers-driven systems(no war but the math war)
- coffee shops
- libraries
- parks
- laser cut neon green acrylic
- high density polyethylene(HDPE) sheet from milk bottles
- clotheslines
- black nylon parachute cord
- black soft cloth
- felt cut out in geometric shapes
- bamboo
- neopixel colored LED light strips 
- sacred geometry, occult geometry, occult symbology
- chaos magick
- arduino
- DIY
- craft
- raspberry pi
- the Watershed Network
- the Street/Path/Way, street network

## Images

![](https://i.imgur.com/Se6eZr0.jpg)
![](https://i.imgur.com/Qg40z9U.png)
![](https://i.imgur.com/HjIj00h.jpg)
![](https://i.imgur.com/HwXfmp8.jpg)
![](https://i.imgur.com/ziZfYgD.jpg)
![](https://i.imgur.com/UVbuIU1.jpg)

