[home](index.html)

[Action Geometry Scroll](scrolls/actiongeometry.md)

[skeletron scroll](scrolls/skeletron.md)

# Box:
![](https://i.imgur.com/qHFkNbg.jpg)
# Kit:
![](https://i.imgur.com/pQHrP2k.jpg)
<pre>
kit:{
  scissors,
  6 inch ruler,
  3 inch equilateral triangle,
  duct tape: 
{black, red, orange, yellow, green, blue, purple},
  box cutters,
  googly eyes,
  sharpie marker,
  corrugated cardboard,
  trash tie,
  tape snake
}
</pre>
# TrashTie:
![](https://i.imgur.com/LmjOsiJ.jpg)
6 foot long cut clothesline, duct taped both ends
# Tape Snake

![](https://i.imgur.com/WKFQRVY.jpg)
Loop Trash Tie through a set of all colors of duct tape twice, tie with a square knot.

# 6" equilateral Triangle
![](https://i.imgur.com/bmOahHu.jpg)
# 10 Traced Triangles:
![](https://i.imgur.com/Mwbm4vo.jpg)
# Layout:
![](https://i.imgur.com/XZlHq3v.jpg)
# Assembly
![](https://i.imgur.com/v3L22TO.jpg)
# Rainbow Skin
![](https://i.imgur.com/fNFyIA2.jpg)
# Hole Punch
![](https://i.imgur.com/ylJHIF8.jpg)
# Box Tie
![](https://i.imgur.com/0P5nGbZ.jpg)
# Box Box
![](https://i.imgur.com/wQTEjlY.jpg)
