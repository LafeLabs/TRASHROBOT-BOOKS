[home scroll](scrolls/home)

#  <span style = "color:red">Γ</span><span style = "color:orange">ε</span><span style = "color:yellow">ω</span><span style = "color:green">μ</span><span style = "color:blue">ε</span><span style = "color:purple">τ</span><span style = "color:red">ρ</span><span style = "color:orange">ο</span><span style = "color:yellow">ν</span>

# Geometron

![](https://i.imgur.com/ETvXBCp.png)

by Trash Robot

 1. [Civilizations](scrolls/civilizations.md)
 2. [Organic Media](scrolls/organicmedia.md)
 3. [The Street Network](scrolls/streetnetwork.md)
 4. [Servers](scrolls/servers.md)
 5. [Scrolls](scrolls/scrolls.md)
 6. [Feeds](scrolls/feeds.md)
 7. [Maps](scrolls/maps.md)
 8. [Symbols](scrolls/symbols.md)
 9. [2d Web Graphics](scrolls/web2d.md)
 10. [Shapes and Fonts](scrolls/shapes.md)
 11. [Action Geometry](scrolls/actiongeometry.md)
 12. [Printers](scrolls/printers.md)
 13. [Geometron in 3d and beyond](scrolls/geometron3d.md)
 14. [Magic](scrolls/magic.md)
 15. [Full Stack Geometron](scrolls/fullstack.md)

[Book .pdf to print(8.5x11)](https://github.com/LafeLabs/bookofgeometron/raw/main/main-bigpaper.pdf)
 
[Book .pdf 6x9 format](https://github.com/LafeLabs/bookofgeometron/raw/main/main.pdf)

[buy 6x9 format printed at print-on-demand lulu press](https://www.lulu.com/en/us/shop/lafe-spietz/geometron/paperback/product-qqk98g.html)

[Book Code](https://github.com/LafeLabs/bookofgeometron)

