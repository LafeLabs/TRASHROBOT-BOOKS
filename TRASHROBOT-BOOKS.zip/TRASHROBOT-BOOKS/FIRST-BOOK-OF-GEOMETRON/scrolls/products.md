[home](index.html)

# Trash Robot Products

- ArtBox
- Laser cut acrylic Geometron Shape Set
- Laser Cut 6 inch Geometron Ruler
- Custom on-demand laser cut shapes for customer
- Magic Shield Pyramid with various technologies
- Raspberry Pi Trash Robot Terminal
- Icon Token Printer
- Custom or random Icon Token
- Custom or random Icon pendant
- Sigil Board with Icon Token Set mounted on Token-U's
- Set of Icon Tokens with specific meaning in a water bag
- Set of Icon Stamps in a fire bag
- Earth Icon Print
- Custom Icon design and Geometron Glyph
- Custom link feed preparation
- Custom Image feed preparation
- Custom scroll to share and replicate
- Custom map to share and replicate
- Skeletron structure made of Trash Poles and Trash Ties, with S-Hooks, ArtBoxes and TapeSnakes, Flags, Bags, Sigil Boards, and Replicator Deck



## ArtBox

![](https://i.imgur.com/qHFkNbg.jpg)
![](https://i.imgur.com/wQTEjlY.jpg)

## Laser cut Geometron Shape Set

![](https://i.imgur.com/oCXWSGN.jpg)
![](https://i.imgur.com/TD5Sqs6.jpg)
![](https://i.imgur.com/BtOx3D1.jpg)
![](https://i.imgur.com/vkUCCZP.jpg)

## Laser Cut 6 Inch Geometron Ruler

![](https://i.imgur.com/xt1HCtu.jpg)

## Custom Laser Cut Shapes

Any spray stencil in any material

![](https://i.imgur.com/ciuNvik.jpg)

## Magic Shield Pyramid

![](https://i.imgur.com/1RFYgKx.jpg)

## Raspberry Pi Trash Robot Terminal

![](https://i.imgur.com/SteZ5V8.jpg)
![](https://i.imgur.com/Nq6ql9O.jpg)
![](https://i.imgur.com/yvbgOm0.jpg)

## Icon Token Printer

![](https://i.imgur.com/tz8x0hY.jpg)

## Random Icon Tokens

![](https://i.imgur.com/BbU0bAX.jpg)
![](https://i.imgur.com/IJhVFZb.jpg)
![](https://i.imgur.com/FIZuT0P.jpg)

## Custom Icons

Any symbol any icon, characters, glyphs, emoji, etc. We will find an image and trace and turn into Geometron Hypercube Glyph code to share freely through the Network.

## Pendant

![](https://i.imgur.com/K1w4bk8.png)
![](https://i.imgur.com/qIdr2zT.jpg)
![](https://i.imgur.com/J8ZmGNk.jpg)
![](https://i.imgur.com/Wd794fs.jpg)
![](https://i.imgur.com/affCIzH.jpg)
![](https://i.imgur.com/ovnrRq5.jpg)

## Sigil Board  or ArtBox with mounted Icon Set

![](https://i.imgur.com/nVZcixi.jpg)
![](https://i.imgur.com/uARp7Id.jpg)
![](https://i.imgur.com/lzWdl1M.jpg)

## Icon Token Set in Water Bag

This is the alchemy of Trash Robot, form of Alchemy:

Think of a thing.  A desire or intent. Now break that thing up into a set elements.  Assign a symbol to each of those elements. A Trash Magician can take that set of symbols, map them to Geometron code, express that in clay with the Trash Robot Token Printer, make stamps from the prints, then stamp out sets of Tokens which are painted and sanded and put in a Water Bag.  That bag is carried around and used to focus ones mind on the original thing from the beginning of casting the Trash Magic.  

## Icon Stamp Set in Fire Bag

## 
