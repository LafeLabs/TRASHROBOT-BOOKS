[mathuser.php?scroll=scrolls/math.md](mathuser.php?scroll=scrolls/math.md)

[mathuser.php?map=maps/math](mathuser.php?map=maps/math)


[back to normal user home screen](index.html)

[link to math map editor](mathmapeditor.html)

[link to math map](maps/math)

$$
\frac{-\hbar^2}{2m}\nabla^2\Psi
$$