[home](index.html)

[action geometry scroll](scrolls/actiongeometry.md)

# Geometron Protractor

### 2 layer vector file:

[![](iconsymbols/protractor.svg)](iconsymbols/protractor.svg)

### vector file of outline:

[![](iconsymbols/protractoroutline.svg)](iconsymbols/protractoroutline.svg)

### bitmap of laser etch layer:

[![](iconsymbols/protractor.png)](iconsymbols/protractor.png)

### laser cut in neon green acrylic:

![](https://i.imgur.com/dXgcK8P.jpg)

[laser cut on demand from Ponoko.com](https://www.ponoko.com/)

